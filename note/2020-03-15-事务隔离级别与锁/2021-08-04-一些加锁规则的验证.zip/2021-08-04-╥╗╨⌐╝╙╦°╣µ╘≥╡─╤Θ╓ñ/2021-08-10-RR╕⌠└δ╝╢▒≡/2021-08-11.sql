2. 唯一索引、普通索引

3. 范围查询、等值范围查询、等值查询
	起点、尾点
	
4. for update和lock in share mode、DML