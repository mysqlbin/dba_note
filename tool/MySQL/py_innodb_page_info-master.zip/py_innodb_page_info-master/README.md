# py_innodb_page_info

python tool for innodb page info
 
首先 要安装python

用法 ：

D:\> py py_innodb_page_info.py server_cost.ibd -v

- v 表示详细信息
